<?php
//Funcion conexi�n base de datos con meekrodb
function keyretrieve(){
	$key = "TheKey0123$";
return $key;
}

function conexionBD(){
	require_once ('meekrodb.php'); //Uso de la libreria meekrodb para el uso de la base de datos.
		DB::$user = 'userdb'; //the user of the database
		DB::$password = 'password'; //the password of the database
		DB::$dbName = 'rust'; //the name of the database
		DB::$host = 'localhost'; //the host of the database
		DB::$port = '3306'; //the number of port, of the database
		DB::$encoding = 'utf8'; //dont change :)
}
?>