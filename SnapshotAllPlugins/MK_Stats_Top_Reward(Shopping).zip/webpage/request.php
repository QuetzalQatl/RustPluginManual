<?php
require_once("./inc/config.php");
$key = isset($_REQUEST['key']) ? $_REQUEST['key'] : '';
$op = isset($_REQUEST['op']) ? $_REQUEST['op'] : '';
$req = isset($_REQUEST['req']) ? $_REQUEST['req'] : '';
$userid = isset($_REQUEST['userid']) ? $_REQUEST['userid'] : '';
$name = isset($_REQUEST['name']) ? $_REQUEST['name'] : '';
$nameD = isset($_REQUEST['nameD']) ? $_REQUEST['nameD'] : '';
$useridD = isset($_REQUEST['useridD']) ? $_REQUEST['useridD'] : '';
$points = isset($_REQUEST['points']) ? $_REQUEST['points'] : '';
$killings = isset($_REQUEST['killings']) ? $_REQUEST['killings'] : '';
$deaths = isset($_REQUEST['deaths']) ? $_REQUEST['deaths'] : '';
$suicides = isset($_REQUEST['suicides']) ? $_REQUEST['suicides'] : '';
$pointleftS = isset($_REQUEST['pointsleft']) ? $_REQUEST['pointsleft'] : '';
$money = isset($_REQUEST['money']) ? $_REQUEST['money'] : '';
if($key == keyretrieve()){
conexionBD();
	switch ($op){
		/*case "status" :
			if(conexionBD()){
				echo ("OK");
			}else{
				echo ("FAIL");
			}
		break;*/
		case 1:
				DB::query("INSERT INTO users (userid, name, points, killings, deaths, suicides, money) VALUES (%s, %s, %i, %i, %i, %i, %i)", $userid, $name, $points, $killings, $suicides, $money);
				echo('SUCCESS-PLAYER-ADDED');
		break;
		
		case 2:
			if($req == 1){
				$latest10 = DB::query("SELECT name, points FROM users ORDER BY points DESC LIMIT 0, 10");
				echo json_encode($latest10, JSON_PRETTY_PRINT);
			}elseif($req == 2){
				$results = DB::query("SELECT points, killings, deaths, suicides, money FROM users WHERE userid=%s", $userid);
				echo json_encode($results, JSON_PRETTY_PRINT);
			}
		break;
		
		case 3:
			$player = DB::queryFirstRow("SELECT userid FROM users WHERE userid=%s", $userid);
			echo($player['userid']);		
		break;
		
		case 4:
			$player = DB::queryFirstRow("SELECT points, money FROM users WHERE userid=%s", $userid);
			$result = $player['points'] - $pointleftS;
			$Rmoney = $player['money'] - $money;
			if($Rmoney <= 0){
				$Rmoney = 0;
			}
			if($result >= 0){
				DB::query("UPDATE users SET points=points-%i, suicides=suicides+1, money=%i WHERE userid=%s", $pointleftS, $Rmoney, $userid);
				DB::insert('logs', array(
					'useridkill' => 0,
					'namekill' => 'Suicide',
					'useriddeath' => $userid,
					'namedeath' => $name,
					'pointswin' => 0,
					'pointslost' => $pointleftS,
					'category' => 3
				));
			}else{
				DB::query("UPDATE users SET points=0, suicides=suicides+1, money=%i WHERE userid=%s", $Rmoney, $userid);
				DB::insert('logs', array(
					'useridkill' => 0,
					'namekill' => 'Suicide',
					'useriddeath' => $userid,
					'namedeath' => $name,
					'pointswin' => 0,
					'pointslost' => $pointleftS,
					'category' => 3
				));
			}
		break;
		case 5:
			$player = DB::queryFirstRow("SELECT points, money FROM users WHERE userid=%s", $userid);
			$result = $player['points'] - $pointleftS;
			$money = $player['money'] - $money;
			if($money <= 0){
				$money = 0;
			}
			if($result >= 0){
				DB::query("UPDATE users SET points=points-%i, deaths=deaths+1, money=%i WHERE userid=%s", $pointleftS, $money, $userid);
				DB::insert('logs', array(
					'useridkill' => 1,
					'namekill' => 'Natual',
					'useriddeath' => $userid,
					'namedeath' => $name,
					'pointswin' => 0,
					'pointslost' => $pointleftS,
					'category' => 4
				));
			}else{
				DB::query("UPDATE users SET points=0, deaths=deaths+1, money=%i WHERE userid=%s", $money, $userid);
				DB::insert('logs', array(
					'useridkill' => 1,
					'namekill' => 'Natual',
					'useriddeath' => $userid,
					'namedeath' => $name,
					'pointswin' => 0,
					'pointslost' => $pointleftS,
					'category' => 4
				));
			}				
		break;
		
		case 6:
			$playerD = DB::queryFirstRow("SELECT points, money FROM users WHERE userid=%s", $playerD);
			$result = $playerD['points']-$pointleftS;
			if($result >= 0){
				DB::query("UPDATE users SET points=points-%i, deaths=deaths+1 WHERE userid=%s", $pointleftS, $useridD);
				DB::query("UPDATE users SET points=points+%i, killings=killings+1, money=money+%i WHERE userid=%s", $points, $money, $userid);
				DB::insert('logs', array(
					'useridkill' => $userid,
					'namekill' => $name,
					'useriddeath' => $useridD,
					'namedeath' => $nameD,
					'pointswin' => $points,
					'pointslost' => 0,
					'category' => 1
				));
				DB::insert('logs', array(
					'useridkill' => $userid,
					'namekill' => $name,
					'useriddeath' => $useridD,
					'namedeath' => $nameD,
					'pointswin' => 0,
					'pointslost' => $pointleftS,
					'category' => 2
				));
			}else{
				DB::query("UPDATE users SET points=0, deaths=deaths+1 WHERE userid=%s", $useridD);
				DB::query("UPDATE users SET points=points+%i, killings=killings+1, money=money+%i WHERE userid=%s", $points, $money, $userid);
				DB::insert('logs', array(
					'useridkill' => $userid,
					'namekill' => $name,
					'useriddeath' => $useridD,
					'namedeath' => $nameD,
					'pointswin' => $points,
					'pointslost' => 0,
					'category' => 1
				));
				DB::insert('logs', array(
					'useridkill' => $userid,
					'namekill' => $name,
					'useriddeath' => $useridD,
					'namedeath' => $nameD,
					'pointswin' => 0,
					'pointslost' => $pointleftS,
					'category' => 2
				));
			}
		break;
		
		case 7:
		DB::query("UPDATE users SET points=points+%i, killings=killings+1, money=money+%i WHERE userid=%s", $points, $money, $userid);
		DB::insert('logs', array(
					'useridkill' => $userid,
					'namekill' => $name,
					'useriddeath' => $useridD,
					'namedeath' => $nameD,
					'pointswin' => $points,
					'pointslost' => 0,
					'category' => 1
				));
		
		break;
		case 8:
			$player = DB::queryFirstRow("SELECT money FROM users WHERE userid=%s", $userid);
			$money = $player['money'] - $money;
			if($money >= 0){
				DB::query("UPDATE users SET money=%d WHERE userid = %s", $money, $userid);
				echo ('SUCCESS');
			}else{
				echo ('FAIL');
			}			
		break;
	}
}else{
	echo('KEY-NOT-EQUAL');
}

?>