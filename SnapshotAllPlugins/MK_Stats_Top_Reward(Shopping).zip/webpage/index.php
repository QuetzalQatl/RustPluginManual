<?php
require_once("./inc/config.php");
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>MK Stats RUST</title>
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- <link rel="stylesheet" href="css/bootstrap-responsive.css"> -->
	<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/toggle-switch.css">
	<link rel="stylesheet" href="css/style.css">
	<!--[if lt IE 9]>
	<script src="dist/html5shiv.js"></script>
	<![endif]-->
</head>
<body>

	<div class="container">
		<header>
			<img src="img/logo.png" alt="ML Bootstrap Template">
			<h1>MK RUST STATS</h1>
		</header>

		<div class="row navRow">
			<div class="span12">
				<div class="navbar">
					<div class="navbar-inner">
						<ul class="nav">
		  					<li><a href="#" class="MKreq" ref="Home" chr="home">Home</a></li>
		  					<li class="divider-vertical"></li>
		  					<li class="dropdown">
							    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
							      Top 10
							      <b class="caret"></b>
							    </a>
								    <ul class="dropdown-menu">
								      <li><a href="#" class="MKreq" ref="TopP" chr="top" tabindex="-1">By Points</a></li>
										<li><a href="#" class="MKreq" ref="TopK" chr="top" tabindex="-1">By Kills</a></li>
										<li><a href="#" class="MKreq" ref="TopD" chr="top" tabindex="-1">By Deaths (Noobs)</a></li>
								    </ul>
							</li>
							<li class="divider-vertical"></li>
		  					<li><a href="#">Most Wanted</a></li>
		  					<li class="divider-vertical"></li>
		  					<li><a href="#" class="MKreq" ref="" chr="users">Users</a></li>
		  					<li class="divider-vertical"></li>
						</ul>
						<form class="navbar-search pull-right">
		  				<input type="text" class="search-query" placeholder="Search">
						</form>
					</div> <!-- /.navbar-inner -->
				</div> <!-- /.navbar -->
			</div> <!-- /span12 -->
		</div> <!-- /row -->


		<div class="row navRow">
			<div class="span12">
				<div class="hero-unit">
				<div id="responseMKreq">
  					<h1>Latest Statistics!</h1>
<div class="">
				<ul class="nav nav-tabs">
					<li class="active"><a data-toggle="tab" href="#tab1">General</a></li>
				</ul>

				<div class="tab-content active">
					<div id="tab1" class="tab-pane active">
						<table class="table">
							<thead>
								<tr><th>Description</th></tr>
							</thead>
							<tbody>
								<?php
								conexionBD();
									$latest = DB::query("SELECT * FROM logs ORDER BY id DESC LIMIT 0, 10");
									foreach ($latest as $row){
										if($row['category']==1){
											?>
											<tr><td class="alert-success"><span><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAGTUlEQVR42r2WCVCUZRjHn293P/aCFZQbBTFhVU5R866kEa/JSS2n1DyaQkgNNdF0UgcYRZuUyQOw1FSQdCwJjzQPDsUjUShHLkG5j10W2Pv79jt7dw1HywNQeGZ23m92nu/9/97/+993Xwy6WUql0i40bMTPZaUltIUkl5eVlWm6Mw/WXYCNmzaleHh6RaWnp4PJoK+laXpuSUnJn70CsDQqKnLqtGn7Un/4EQw6HTAsCzRJUKhWFRcXJ/cowHszZ46Lio7OPnjosLi+thY4jgMME6CRBY5lgKaoo8iNpWhLTD0CEBef8KBJpRqEBMBsNttEBUKRDUCAYcAjIJSJuxaLJaK8vFz12gGCg0PS7RWK+TzP21b/yAHMNoIVAG0Hz3PWqfMYyrKLZpis0tJS9rUBpMctmFLczJy7cKsCw4RCm7h1GqsT1mfEBa6uLqAcFghFOZdhMM/fc3d33yoKDf0lbutW+pUB8lOiL+u0qvDcokrIfSgEXoDbvuc53jYbLhJBUEAQVBfdATeGgSHImdFoZGXyRsbJMU3n1f/EXe8BhdsTEvguA1zYv863D6OprHpYLOB5GuoadHCqQgYEZ2dFsIXx7fBwKMzNBSNDgyeCsiCFoWhbSOTOZ6QFMIEASIVDE+7mlq3GsOwuAVw5uGyTgDbHaetLoVVvAnuGgOo2FjLvSwkzL5EOCwwEEolUPai09YvRftijTysSHY9cWEySthULJRKQKxSg4bj6TgNczDwglZFVD9pr/vYgTe0gp7TQbqShXstQ7fjgUSdvVPd1UCi+5lh2yqNcAMiR/SYkrkQOxBAE4P9aLnFwADsE0ELRWZ0GuJq+YSMugnhT3R3QalqAJQloMrBgYh02bTh8J8Ha4+fn5yaXy8uFQmGfjvc8EcRytHIheq5DMCEIRuHsbAusWiKZ3ymA31NXh7q79buhrb4lofUqULcawUDy0GKE/KCpUZNmL1zBdPQGBATsFIvFqzpcWIrErdG/h8LphWAmTJwIA9AZQmFYeYGfX+BLAa4f2+wqlUpu6uuLfcm2KjAYSXTwYNDQxjZzToEjYxLTGp7s9/f3H4JcKBEIBFgERUEflIEiJO6PVu7h4wPhYjFgAQG8uqrqnYlpaVdeCJB7dIu8rwOXQ1GWUS2leUCYCdBbAIwUmIUOPuHRib8+888nODj4ejjAWHe04nwchwk0DRSyfYa3N3h+PA/qblzf8WZ8/BqAF/wMczP34c5C1SmGpaY2PywG1qgCDdpzI2fPsnbOc77cdjzree+uDAlZ+QbDJGWi1b5vsYC9UgkjfX3B5fNIUN8uyCm8di1iSUoK81yAnPMnMWn77QNimWxJQ00lsPomYMw6UBMinnLwj4yJP7j/Rc5tHjPG7yZF3Q9HtvuEhUGooxPIFi8GorLir5rs7EkRe/dqO3qfCZB/JHatBJjtjaoawFgaWHM7tJo4aGWcvln7/dktnQluxpwPagcNDx3gSJBgh4JHAl+oycqa9lZKivrJvv8B5O1e9C4K3R/VlaVCToSDWMSCwURBk0m6d13y5eWdEbdWwc6k430oy1xz336gVyqzGjMyFny0L9X4376nALL3xThL2ba7jRXlHjqzCWhMCEKRAHSc4vTQyVGzps+ax3YaYP36BEwmj24YPnzjiePHUtPT0vhn9T0FkJ+86KiuRT1PVfsQaJoCwk4KDC8plg0cN/aLjXsMnRW31qnpMwbeCArSJG7fZnxR32OAq4fXhFu09Zcam1UYZ2xDlw0SGAw3Yy4Bo1YkHi/pinhXygaQd/GMgKk+W6BqbggjTSag9K3oqOSBkXjGLttx7rueEn8MkHsodhahrjhZ304AhY5OYFBmAS/zGL0weM6CSPpVRV4KcGbXkpvGltrRZr0RCF4I9jgHJO42d+m2rBM9KW4DyNgdO4LUVNzmjK1AI3EZbwYjyVe4jpo39MNPV3U69d0GOJ30SRKhb1mp0xvQdQoHAdkGGrrf6tXJOUk9LW4DOL974T1tw4MAcV8XAFMbNKq0rL3fVK9FX3370iv1awHI2jm/nSYNjhyGg1Bfh048yaXlu65M7g1xG0BG3OyfQMAt5kkDmPQ6mrDrHxGz47fcXgM4eWQPpqkqGE+31Xjijt6FkXFHKntL3AbQm2LPqn8AomUONwj2sAoAAAAASUVORK5CYII="></span> <?=$row['namekill'];?> has killed <?=$row['namedeath'];?> and he has won <?=$row['pointswin'];?> points</td></tr>
											<?php
										}elseif($row['category']==2){
											?>
											<tr><td class="alert-info"><span><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAIjklEQVR42q2XC1BU5xXHz9579+7dvTx22V0WWFDwHbQkJKM0ZXxMWhsytIlmtNo42jjVSUZNfStWUUGkvhARBYWkkdqo+GjFoDU2kljNaBMHJQK7vAyLyALLvt/vnntbO+loHFz7zezs7N1vv/P7zvl//++sAJ5x3Gv6KiVOGrOIIIlpJEmM8Pt9IZfLrXO5XFf7B00nX8+Z0/cs6wmGO7Hx9lU2XqksYiWSZQJCQIfDYQgEAuDzeSEYDIDb7QaE8NrtjspBg3XbnF8ttv3fAG5/3TA6KSn+gogWphMECUKhCLh3r9cNTqcdAn4/OJwOcNht+MwLbo9HZzTZ3l6wcEXjcwNcv3Zx5IiUxJs0LUwUCATAsjHARsshHA6C02EFi3mIh3C5nGA2mcCOED4fAjmcFqvN++qa9du1zwXQ1Njwt9jY6Bwu5RyAUqkGWiQGv98LNqsZhob6wevx4Gcf6PV9YLPZIBQKceUAi8VxbfO20hkRA1yqPzUqdWRCJ02LBARBYK2DIJcnAElS4PG4MJgZISx8QC9qoR8BQghqs9owuBmMRhMICOZHxbsrmiMC+OLvZ5ZIpdHVYgmLdRfiZAEwkiheAw67BdNt5XceCoawDA6wIowHszFkNELfw4dcGRBAuPFA+fE9EQFcvHBsr1BIrZPJZMAiRADV7kfBicUsH9jtdgGKAUHs0N+v5zPEZcI4ZITe3oc4P4iwzPHDR04tigjg5PGyKqvVvFSlUkFycgofiBMZ987pgaIoXnwPHvTiZ4AoNgqCWA6TyQwGg4FfXkgzlyqO1uZGBFB9pLjcajGtiI2NhVGjRsPt27ehpVXL7zRZrQLuuQmVr9cPQHuHDoEIUKmUkJKcxIuQg0SAC5VVZ96KCODwwcK1Lqd1H1eCz658Dnca72JNCUwrDb/InQmZmZmg1WrhH9dvQleXjj8ZnFhTUlJg4gtj+bm0SFKDGXg3IoCDpYVv+H22SyymtvLIhygqO+98NIpw69ZNMHbseOjuvg9nz56DW/+8g5nxA00zkJSUABPTx/GiFTGSsoqqM6siAigrLUqBkLMHPR/q6uqhr68PPOh0r7ycCRvzNqD+KHjQcx9aW5uh9nQdCrEfCAEBGRkTQY0l4rwjKka+9lDFif0RAXBj3671HfHxijGcquvO14EUy7F8xXI0IAPsLylDTyBh2rRskMnioKHhGq+Pl16ahJmgeaOKkSVOLSuvuRExQO2Jw+eS1Ylvd3V1QnNzM+/1arUa2tvb4Pr1G3gUfRgwA9OexF9KXN158eEJ4Q6EVDk6sXjnbl/EALuL83LcLmu90WQkfT4fMCIaUlPToKdHB5cvX8a7wAlZP56Mx1SNcB4+7cFAkD+ObFRsaWXV6TVPW39Yt+EHy35dajD0r2JZFlRKJfwkO5vPRE1NDW9GU7KygEJ71qMGcMn7TofDTFFCmSI+JauktGqo/tNTgnFj0nL7+vTdM346q/mpAM1NN37HMMJ3Ozs7C3JyF9Rxz/I2rhQODT5Ygg7YmZysrJ0+bTqWXIF+b4IeXTe/a06gHR0dQAnZn5Ud+tPVrfmbicIdO0Of/LlaMDV78kF/wL/iQt1fbA6XSJq/dXv4BwHO1lbWKeSyN9H7A06Xd9nP33in+vvfH/uoZHN6+oQiuTye94OB/oe8O2q0Grx8zANbCw4mPJr7ZUM9nZqqPuiwW9/78ourgJtyxyekJv5+yx+sTwRo+farSSIR9Vn3d+1J3BUrRWUTJHXGanWvy8md38PNKSpYPV6uUJyjhXS6QhGHeiPQHxycPXuxNStavW5HETdP03JzSnR0dEWPruuV9jYN+gEDsTEx4HR5WrVtuqz8bbsdjwHUnfvwikAQnhkM+nhH414SiQQtV+YBAXnUbHaWzMyZ84Cbu3jR7My0tNQZKlWCvL2jU+P1BhoOVXysx8BpeCcUuJy2BRpNMzFkHPrPHWLnQb0en1MskY3btbei7zGADWuWvBgMet4iCYECSzCWZcVTZDJpnEKpAIUingPxhYE8YXe4yma8Nvvu93+rbbmVGhMTned2Oxe3aVvpzs4O3picTlcTnoh6imJuESR5n2Fieop3HXAM6xTk52+igt6hqSQZmh/Fiucp4+NjExOTOJgwSYmu+XyBcoaJ0iYmqtY6HLaFWk2LsLW1hQvs9PkDn9A0W1ly4KO7T4sx7K54y6ZVrN9vmUtT5PvYpGRlvJgJEye9jDV1QWvLt/hqgUGDYSAQCJWzUfLKXXsOmYaz7rABHo3O9m+medzuSooi01uam0Cj0YAZ26/09BdgwviJtQDE/uzpb3493PWGBfD5lTrh2DGps7E7WmUyGV5tvtcEbW1tYDRZNPjfoF7CCOfjfZEyYsQISExSo3CjG7HefzSZHSdnvj7HFBHA+boTgjFpI9PjZNJ30OMXDQzok1tb70FXZxcakO0O9npFMTL1+cLC4tCWzespm6VvFkXCqtjYqOwk1IkqQYUNrNIrYsQN2MReCoeJRqfT3Wuzuyy5v5xneyJAR9s3OdHRUYsJAakKh0MT0OlUvb09oOv+Drp1OjCbLSgochsjVn66t+RA+Engq1cunhwMeDZIxPRsqVRK4np4eqQQJ5fzfSV20OG29vvr31++ueQxgIsXaroJQjDSZrOCBz2eu1r1+n4YGDDo0Afy4hQjT28v2BkaTtnWrl463uuxFYpoai7DiAQej5e/P/j/FwRVdaiy9r3HANas/M2scMhXnZGRoQhiq411Dnu8gVIxK8vfs/ew69nk+u+x8oNFUwN+9zExIxrFAfj9wTMJ6vR52wuKwk/UwMfVe6uCQe/Se/da0A7phdhMnI4k8P9u7Ldxbrf1fDgURE8R7j589HTeD4pwx/bVCwYH9ftIkll2oPzYX583+KOxYf1yxuOyzmXE0Rf37Kv878n4F1vkL119NOiRAAAAAElFTkSuQmCC"></span><?=$row['namedeath'];?> was killed by <?=$row['namekill'];?> and has lost <?=$row['pointslost'];?> points</td></tr>
											<?php
										}elseif($row['category']==3){
											?>
											<tr><td class="alert-error"><span><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAIwklEQVR42q1WC1BU1xn+7/JYQBYQqOITRQbU1UGkinE0vh9VaCdmUEkUUdB0MokJxCo2tjEa8a0Va1QUxRgDalOtTquCAz4aoWIFBIyoUQMYkOWx4LILy917+/2XXYIR0XRyds6ce+/+5/++/3mOQK84HBwcRgmCEI3HOZgWWZaPYD3a2tp6p6Pcli1bvFtFcUdNTU2onZ3dQew5abFYynZs3y51pld4RXAtAL/EHI5XO2WjIJixXMF8SxRFnU12Q+KGoIaGxmMtLS1aF5duzfb2drkmk2ndtq1bs/8vAvb29l4A3obHaHd3d+rXvz9ZRJHKy8upqamJRdZjbgIJI7+sWbNmHABPqJ2cerm6asjdw4PUjo7GRw8fRDY2NJ5P2p1k/rkEhkuSlObq6qodPnw4BQUFkWSx0PUbeVR6p5Sam5uvwhuRIPCY5RPXrhwviS0njKLaw07tbPLz8/NwdnERAHSvML/g/cTEDRd+FgHEcQE8sHPAgAHeYWFhFBISQuYWM32T8w1lZmRSZWVlMQi8hTgXsfy1k5/NMenup3yScn3FQO2vT0yZMjXfy9vLz9PTSzCbzT+cOX1qMsje3b17t/yqBD6FB/4QGBgIQ1woIiKCoIgOHTpEKpWKyjBAcBlkFMuyjq45dvXy5QnbjuePevrUUJm4adO2UaND3/P28lRDAeXm5Bz5b15ePAjUvZQA3C9AeTqUz9VqteTu7kbTp00nSZbodsm39ODBAyooLLDg/82Q+1Pm33dpm8vyL21JvZhe8J3+AxAQI+bOVffr12/WtBkz1voP8tcaTUZT5oWMuBt511PS09PllxHoD8WZAAjg2M+fP48EWF2rqyXXbi709alTVFRURJDJCZ85ftbKJTMW5mRnJuz8uvDdH57U/6OjrpUJCSMnTJiwPWjEiInf3r5dcujgwdC0tLQmoSvrsSzA/ALxpZ49e9KgQYMoaVcSaeCJ+Lg4ulVYSOUVFSzeOn5M0Jw/Ro1dtffoucZrd+sX6Gr09T/VOT8yssei6MXnAgIDgvfv3fv23dLS9K4IaLCsxYznd2dnZ4qKiqKYmBhCk6FLl7IpNfUIVVVVsQfojWkhVyPH9R2xOvnKxzqDuL9B32juTO++5OQ5Y8a89nnRrVt52dlZi7si4IflK8xQfkcYyMfHh95Ztozc3DV05MgXVFxcooBzjZ3aEUU5OflV+87fH1lXb6h8kd4lMbHOr40du9Xf3/+Nk8fTIl9IAN2vD5TvA3CYtRoUME9PT3jDiaqfVJOI0BDJFODrQwdXT6VP92Yk597Tv6dvMLZ2lVvLP/xwWHj4b69lnD+3qlMCjo6OwLObDC/Eg8hMBueSs3mCp0rF3wRC16M170yhXoJOWp1aePVJfcuf4ZH/oFRbuiKxb39yZm1tTZ3QCbgzGss81Px6PPcBOJeiYj2PtpXfSSHlrXGklNUz6PDxi3Tiej21mFvLcEDthtBfQEJ8EYH1n22Id3B0iBZ+Cg7AtUi4d/HsarOY0eR28LYh4NdkNNHcmSModpIXLdl8maqe8leJuGpAYj13UJCo74zAxs2bx1lEyx6hA7iae3q3bt2SrBVAbZZLirUKAenHE5X/MxiMdPqv0VRRkk8rD98hSXhGRo+Wuw5yu0DiuaN4xcpVgc5OTgcEKziwhcWwfCPc2gMbFffiW5sH2hA7eIG/W2jwQB/at3w0rUvOooziJiSqrJyULIvTkGVFHMvR2HACJJ5JzJjY2B7du3u2EwhwcnLKQML5clIxAXxrTzxbKGyEeOXzYPmiqTTyVyZKOJBH1QZJcX9rq6iQhD5FB+SKEY6lWHM7EkCLdkRFbRQYFIJ7YP1ssOWs5ttOE8LgiqliMFbIwBxbW0IGwvqtH4XT/mPn6EJelWK1RbIoC/QbkEsatVqt4gqC3hwYFQYSdR1JREUtihAA/hHi/gneNVbrswH6OWYCCITYCMCKduuZSPjEIIoJH0wfbDpDj+st+C7b/i+gtktKHHSPZRIsD91L8f9h6LfYCMx5802tgHK7BwL+DAChagjPhFA+Ni9FCDZjdrcRsCWfxSLR8e2LKf9mAW1LLyCVtUlxenAiY/4NkiH29g5fwbPcUcloNHIo3obuWzYCs2aHaQSA33Nzc/NnlhAqhNBEuEwPAsOg6EsQCGLhjgT69fKm7e9PoqRjWXSlqIbs7VRKgkK2DHvGYv9j5MBA6EiFga+zZ3B9a0AIoqHndDuBWbNVAhiu9vDwSORYcfLBC4VY86DMgPyYhu98ISW9Xk8ajYYGDxlK86drSV9eSDuO55PBZFESjg8EZPQDgJ2BvAPCNx7u13JLZb0g8B3WhZg5HfNAgNBvQCIdTF05622tVmgbSiXg3qcIL42Npbo6Hb3u10on/5VLJnj3Mk5Fua2S2lsE72ODbPkCywVYnoD/9oBA0zMEwFSN9XcgkghL+uJdAef/bJ0PoaFJkyapgoODqY+Pp9zL+al87GyubJYdyVGtposZGcJTg0Fg0A4DdkgC5n3MnXhPAfhzDUnpA1xuWMbB2uUgMg3vsq0RMQm2ztfX1y40NNQu0H+gZG5uEs0W3AcrHlNtbS3dyLtBDx89ZAIqa54wEJfzTcyP8ZwP8E7vB8+cBQBmE+YBfB6eh/JBhGeZvcJ3wqFDhqhwK5a640hmr5SW3qFHj76nrKws0ul0Sris4OVYk7GeBbCJuhjPnYZWb/SG9RFQOBmJ6M6+xEoTQ4dRoF9fHDoqEnGdrMB1rKSkhBobG3krN61mAJ/FPI/n+4i7TC8ZXV5K4fpgKPo993Q3Vxd54axgwn2Ssgp1ZIumNWcgIqtAMg2e+ffLQF+ZABQOghfC4EZxzIgAOWx0bzpwKpceVZueOSes1cNtPRtlfPsXIwDrekJ5ADqfJW7BZBKbqmn/mRJqESXlNmQbnP1MAPLfg0DFL+kBDVzbvbePt7Bi/mjpn5duyhk3K4mx2yq1beXklySZE9aAnlH/SsjW8T/Sr6xHqrjGZwAAAABJRU5ErkJggg=="></span><?=$row['namedeath'];?> has committed suicide, and he lost <?=$row['pointslost'];?> points</td></tr>
											<?php
										}elseif($row['category']==4){
											?>
											<tr><td class="alert"><span><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAALX0lEQVR42rVXaXBV5Rl+z7n7npuVRdZokQIWpYgCQRYHF8C9o6N1OlrbH2rruHSmHRfcKNMfgNh2SgURASHcQFayGAjhhoTNJCQhQBJCEpLckLvkrufes37n63uusTMZcao/epIzJ/fck+99vvd93ud5DwM/cJw4XmfVMfrpfr9vAQVmQabbPVuv0+cZTcZcQhQHn0pZFFk2SpKU5AUhFIsn6nheOA6UXuBTydDbH7yvwo84mJvd7Gy7ODsajW684Ru5MzByfXZKkKyiIDAWqw3c2dmQnZMLTqcT4tEwpAQBiCRCkuPURDIVUgi0ccnEoY82b9r9kwFc675mvT7Q9+frAwMvN587n6UQFZwuJ5gsRjDqWAyclX6OSyaB1ZlhxvTpkJmVBb1XeyAweoOarRYqSTIkUzxzfaC/PBaLvX+0trbtRwEY6us3DQ/5XisvK/vA7w+YtV3dsWgRzJwxHUG4AFMLVpsVrFYLcIkYxOIcjI1FcAUKGa4MOHfuLJVlkeoQKFWpGosn1eBYqF1vMDx+qKjI9z8BdLS0vl5ZUfnhiG/EbrOZYf78n0NO3hTIzMwEhmFBREBGkwnsdhtiUdMnUEAQYUjEEyAKPL3QdoGGIlEwGAyqwCeJBlpWqZeo9Hd79+0d/EEAo0O+SSe93vNNp05Ny3DYYdHdd0NWphskWQVXhgt3RECnNwCSEHQGNg1IxXtGkxli0ThICC6RiNFIJEZrv67VvlcNRpbwPK8wOr0Ui8XfKy0v/cdNAZz2NlpEUfq0pqbqJe3GyhUFYLU7IIbpzczLBqfDAQyrQ6Qq6A16DAygcUOPqcYOgCQvgsgn8TsjJkWlLS3N0N7erhIFn6JAGIYqWK6QKAmLj9XVhb8HoMnbmO8b9nlKSorvunPhL+Cee5dBMhHHetvT5GPwR6fTgV7PgtFoBPwAKmVAEQWQFQoiXhkq47NWLAhLr/f3Q0PjKTUU8BOV0RFsVVFRFJ1ClEcqKo96vweg/ljdg6ebzhwYGhxwP/rEr8DtdgP2NfDRCFAWw2PanRkZQIkEDpsNAbCAK4PFbIRUiseYCI4FBAVYgjAd8/vh6rU+tfNiG8GyEcroRVWRAf/YgjnZXFzimaAPTMvZ8y8XeYo/VSnRrVi5Kp1ybceRoB8syIdkSgKzBdlvNiC59EAZHRBCwOWwIFA5zQdeFMFht1KiKlQWJWhtbVdra44Sm81GUqIi2qwmRRDkGnz4lcPFnsQEACdrj28tLPS8Puf222F5QUGal6FQELouXYa5C+aDwWgCm9UKLEuB45JYGtQFkx6sFjOSVAZBEEGWEZDLSRVFokQWocl7Sq1raCTYBMRoNokuh11CQnYrhLxwqKiwbwKA2sqqIs/BwqcK7lsNM2dOw3aTECiFsD8Ak2fdlg6a6XaCjiEgiTJQnRHM2I5WmwUUWcHgspZ+TSOoIomaFkA4FFH37d9PIpEIMVltosVkQr6KNzDei54jngsTAJQdPlJfevjwyoc2PAJTpkyB0pISqK+vg2eeex66u3tgHd7PnzUd+q9dhZ6eXsjIyoH82bdCV3cXpJIpmDQpB8tmh9zcPIrVoEkErOnA/n17STAYJIzeJOr0eoml6hhRpN8XlZY2TQBQuHd/8+nGhkXrNjwKDlyo9usaONnQAH//107YvXMnxOMxePON1yCKpNz+6T9h2fIVUFCwHI4fq4Xy8gp49rmnob6uDjZsWE/z82+jyHpNH1SP5xAZwwwgazGpuH+ei6GJvVpWVX1sIoA9X/bW1tbmP/Hkk6DiP39z7ixUn6iHjzb9DSorjwIQEV559ZV0z2/Z9gncu2Qp3LdyJZzELJWXl8Hmv26C6uoqqD12jH788SaqiZUgSmpZWSkJBEOEIgCthfA3iXry1oGiopIJAIoPHBwp8hyZvAoXxf4CTkjA4eJSmHXrnLTw/PaF38DU6dNA4jnY8e+dMH/eAli4cCF0XGyDmq+rYdNHm6C0rAwaGhrom2/9ibrRvFCe1YaTJ8nQsI/wqOEoBpLJbEoiKf+yv/CgZwKAytKy0YP7D+atW78OxgJBiHIJOH3mPLz40kvwxZ4v4LU//gGm3zIJNFnbvn073InBly5dCq0XWsHj8UDBsuXY91fhvoICOmfuXGo0GACFRz3V0KAM+3xqPMaJvIC9DJAURPHtkoqKwgkAig585fPW1U9Zcs9yzdMhGA7BmbNn4IOPN8PWrdtg4R3z4Jmnn0ILTiEArQT3wOLFd0NrexsUHzkC777zNrYiD9FwmGLGqAtFC5dVmxqblN5r11QcUtIkRGXmMDPvHK2pnAjgwO7PB5tONU1b/8hjwMWi0H2tF0YxE48+/jg47U7YuPE9WLf+YQz6S9i2dQssW7YUVq9aDS2tbVBWVg5vvPkGpJD5MsFyU4VqxsUnOTUSjSktF9oJA1RCt5REicTOtTS/M+QbKpoIYM+X/fV1J2Y++9yvkQMyklaPLDamnU5rsxSfSnu+ZpsDA31gwhRPu2UaDA4NQWvbRXjgoYchP38WXLnSRbH9qJ6lNDoWUkORMOnqukq4RFziYjExmuAjl3u63h0N+I9MAPDlzt29jV5v/nrsdyMavCPLhYxXwJ317RyA9QTN+JFAYLNbQWsz7QwGx8COg4gZVVISBDo8NIgSztIMVEQdy6rtnR2krbUNVVuVUqkk7w+Mhbp7r270BwOl42MATQP4YseOK83NrXPuv38ttqEE2Xm5gPIJZrM5/RSrM8Dw4BBoQ4o2fqWHEbTmwevDoM2IObnZIPACDiVRzSMo+hJmQq92XLpEOto70JVlMRGP8/5gNNjT1/thIBgoG9+8BoAye3ft+sZ7wrto7QMP4uIMzJo5BYxWe1p2jaj52nMySq5WFhNKMGCNZbTg3v4hBJQDWRl2msRntfnAPzpCHU4XpURRT56oIz29/cRiMYkBf0AIhuPBrqtdWyLRSAUuqqVV1q7Mvl2fe095G5YvWXIvNaHx5OZmYmrd4HBqpoOWy8WBxbprHGMZrRQkbT64I5wPreCym3AbjAaO8sgXHExUJCGtqaoiN/wBBTmABinxgVAkcvHypV3xRLwaAyOxgMNTYPZ8tqOy61L32oV3LaZ6DJCdjaMYBstwIxC75VseaAKVSKR3abNZtEShSfHA81K6NAYdpE0sKycXN6/QJHZB5dEq0tc/QHBWlLQyoCjFO690lSSSXD0GjuIZxDPOfLX7c093V+9jK1atIhSHerQ0iOOuXdmTIA/rqyL7tPRz0SjIOPtlZmbhXKjH4DyEwzFqMhlAVQSclszgzpmMXchTVB61uKSEdHZeJnqWlVRQpeHhG1xnV1dFnEs0jgMY1a7Mjm1bPguNxZ9ftWY19iywOOXQFMfRGfn5qoSDhk5vRD2w4g6F9PTrdDrAiKOagvN/JJrAgCpmiWC2HBQFBwdYBcUnRaura8jFi1cU/CxjK0uXOi8n/eGxKkGSTmNgnOfBr12ZTe+9uxabf96aNWusOFxMwzeg2/C9YPKMWTOzMZ9mo9nKulwOFackbWFsAUa1WM0wFgyCyebQ3gGo0cikdQMnOKQDRflN0EOFB0ggFCWjI6NSNBaRR0Z8YV8gUIGPd2Dg8HgG4jd9NaupOm5A/8iz6NmpOoPpZ3a7NQ8NJRO7IVNvNE2VxVQmTkQZcY4z43uDyWIxMylsRXwJUbWUIPHIoYPf2jGmXuwf6PcN+IaO49L947UfwzOk+cNNAdzsOFPvZSnLGllW5xRSnAsnH3dzS2s22ly+QZZmuJyOqegFbrvZlJubnW2trKpWu3v6hOb2tuZwJHyBqOrgeOoDeMbGu0D+0QB+wpGB3XLLvNvnruzu7e1EB9QC8+OtJ433v/pfIfo/APju+G5tdjwY3OQK/wGgoqrYOpsnCwAAAABJRU5ErkJggg=="></span><?=$row['namedeath'];?> has died by natural causes, and has lost <?=$row['pointslost'];?> points</td></tr>
											<?php
										}
									}
								?>							
							</tbody>
						</table>
					</div>
				</div> <!-- /tab-content -->
			</div>
		</div>
				</div>
			</div>
		</div> <!-- /row -->
	</div> <!-- /container -->

	<!-- JavaScript -->
	<script src="js/jquery-1.10.1.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<script type="text/javascript">
$(document).ready(function() {
	$('.MKreq').click(function(){
		var request = $(this).attr( "ref" );
		var chr = $(this).attr("chr");
		$.ajax({			
			type: "POST",
			url: "./"+chr+".php?req="+request,
			//beforeSend: ajaxindicatorstart('loading data.. please wait..'),
			success: function(a) {
					$('#responseMKreq').html(a);
					$('html, body').animate({
        scrollTop: $("#cursor").offset().top
    }, 2000);
				//ajaxindicatorstop();
			}
		});
	});
});

			$links=$('a');

			$links.delegate('click', function(e){
				e.preventDefault();
			});

	</script>
</body>
</html>
