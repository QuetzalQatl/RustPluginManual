<?php
require_once('./inc/config.php');
require_once ('./inc/pagination.php');

// Maximum Items Per Page
$max = 25;

// Maximum Numbers Per Page
$maxNum = 10;

// Number of Total Results in our Table
conexionBD();
$total = count(DB::query("SELECT * FROM users"));

// We Need to know for pagination, our Maximum per page, our Total per page, our Maximum numbers to show (false to disable), and an optional Parameter
$nav = new Pagination($max, $total, $maxNum, 'page');

// Here we run the Query and Limit our Results based on the pagination
$query = DB::query("SELECT * FROM users LIMIT ".$nav->start().",".$max); 

?>
<div id="responseMKuser">
    <h1>List of Users!</h1>
    <div class="">
        <ul class="nav nav-tabs">
            <li class="active">
                <a data-toggle="tab" href="#tab1">General</a>
            </li>
        </ul>
        <div class="tab-content active">
            <div id="tab1" class="tab-pane active">
                <div id="cursor" tabindex="1">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>User</th>
                                <th>Points</th>
                                <th>Money</th>
                                <th>Killings</th>
                                <th>Deaths</th>
                                <th>Suicides</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php

									$i=$nav->start()+1;
									foreach($query as $row){
										?>
                            <tr>
                                <td>
                                    <?=$i;?>
                                </td>
                                <td>
                                    <a href="#modal-container-918004" data-toggle="modal" class="MKuser" userLog="
                                        <?=$row['userid'];?>">
                                        <?=$row['name'];?>
                                    </a>
                                </td>
                                <td>
                                    <?=$row['points'];?>
                                </td>
                                <td>
                                    <?=$row['money'];?>
                                </td>
                                <td>
                                    <?=$row['killings'];?>
                                </td>
                                <td>
                                    <?=$row['deaths'];?>
                                </td>
                                <td>
                                    <?=$row['suicides'];?>
                                </td>
                            </tr>
                            <?php
										$i++;	
									}

									?>
                            <div class="pagination pagination-centered">
                                <ul>
                                    <?=$nav->first('
                                    <li>
                                        <a class="MKpage" href="" ref={nr}>First</a>
                                    </li>');?>
                                    <?=$nav->previous('
                                    <li>
                                        <a class="MKpage" href="" ref={nr}>Prev</a>
                                    </li>');?>
                                    <?=$nav->numbers('
                                    <li>
                                        <a class="MKpage" href="" ref={nr}>{nr}</a>
                                    </li>', '
                                    <li>
                                        <a class="MKpage" href="" ref={nr}>{nr}</a>
                                    </li>');?>
                                    <?=$nav->next('
                                    <li>
                                        <a class="MKpage" href="" ref={nr}>Next</a>
                                    </li>');?>
                                    <?=$nav->last('
                                    <li>
                                        <a class="MKpage" href="" ref={nr}>Last</a>
                                    </li>');?>
                                </ul>
                            </div>
                            <div class="pull-right">
                                <?=$nav->info('Page {page} of {pages}');?>
                            </div>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /tab-content -->
        </div>
    </div>
    <div id="modal-container-918004" class="modal hide fade" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div id="responseU"></div>
        <div class="modal-footer">
            <button class="btn btn-inverse" data-dismiss="modal" aria-hidden="true">Close</button>
        </div>
    </div>
    <script type="text/javascript">
$(document).ready(function() {
	$('.MKpage').click(function(){
		var request = $(this).attr( "ref" );
		$.ajax({			
			type: "GET",
			url: "./users.php?page="+request,
			//beforeSend: ajaxindicatorstart('loading data.. please wait..'),
			success: function(a) {
				$('#responseMKuser').html(a);
				//ajaxindicatorstop();
			}
		});
	});
});

		$('.MKuser').click(function(){
		var request = $(this).attr( "userLog" );
		$.ajax({			
			type: "GET",
			url: "./user.php?id="+request,
			//beforeSend: ajaxindicatorstart('loading data.. please wait..'),
			success: function(a) {
				$('#responseU').html(a);
				 $('html, body').animate({
        scrollTop: $("#cursor").offset().top
    }, 2000);
				//ajaxindicatorstop();
			}
		});
	});
			$links=$('a');
			$links.on('click', function(e){
				e.preventDefault();
			});

	</script>
</div>