<?php
require_once('./inc/config.php');
require_once ('./inc/pagination.php');
$id = isset($_REQUEST['id']) ? $_REQUEST['id'] : '';
// Maximum Items Per Page
$max = 25;

// Maximum Numbers Per Page
$maxNum = 10;

// Number of Total Results in our Table
conexionBD();
$total = count(DB::query("SELECT * FROM logs WHERE useriddeath = %s0 AND category = 2 OR useridkill = %s0 AND category = 1 OR category = 3 AND useriddeath = %s0 OR category = 4 AND useriddeath = %s0", $id));
$name = DB::queryFirstRow("SELECT name FROM users WHERE userid=%s", $id);

// We Need to know for pagination, our Maximum per page, our Total per page, our Maximum numbers to show (false to disable), and an optional Parameter
$nav = new Pagination($max, $total, $maxNum, 'page');

// Here we run the Query and Limit our Results based on the pagination
$query = DB::query("SELECT * FROM logs WHERE useriddeath = %s0 AND category = 2 OR useridkill = %s0 AND category = 1 OR category = 3 AND useriddeath = %s0 OR category = 4 AND useriddeath = %s0 LIMIT ".$nav->start().",".$max, $id); 

?>
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">
        <?=$name['name'];?> Statistics
					
    </h3>
</div>
<div class="modal-body">
    <div id="cursor" tabindex="1">
        <div class="">
            <div id="cursor" tabindex="1">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Reason</th>
                            <th>User</th>
                            <th>Points</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
									$i=$nav->start();
									foreach($query as $row){
										if($row['category']==1){
											?>
                        <tr>
                            <td class="alert-success">
                                <?=$row['namekill'];?>
                            </td>
                            <td> has killed </td>
                            <td>
                                <a href="#" class="MKpageU" iu="
                                    <?=$row['useriddeath'];?>">
                                    <?=$row['namedeath'];?>
                                </a>
                            </td>
                            <td>+
                                <?=$row['pointswin'];?> points
                            </td>
                        </tr>
                        <?php
										}elseif($row['category']==2){
											?>
                        <tr>
                            <td class="alert-info">
                                <?=$row['namedeath'];?>
                            </td>
                            <td> was killed by </td>
                            <td>
                                <a href="/user.php?id=
                                    <?=$row['useridkill'];?>" class="MKpageU" iu="
                                    <?=$row['useridkill'];?>">
                                    <?=$row['namekill'];?>
                                </a>
                            </td>
                            <td>-
                                <?=$row['pointslost'];?> points
                            </td>
                        </tr>
                        <?php
										}elseif($row['category']==3){
											?>
                        <tr>
                            <td class="alert-error">
                                <?=$row['namedeath'];?>
                            </td>
                            <td> Suicide</td>
                            <td>Himself</td>
                            <td>-
                                <?=$row['pointslost'];?> points
                            </td>
                        </tr>
                        <?php
										}elseif($row['category']==4){
											?>
                        <tr>
                            <td class="alert">
                                <?=$row['namedeath'];?>
                            </td>
                            <td> Died by a natural cause</td>
                            <td>Natural</td>
                            <td>-
                                <?=$row['pointslost'];?> points
                            </td>
                        </tr>
                        <?php
										}
										$i++;	
									}

									?>
                        <div class="pagination pagination-centered">
                            <ul>
                                <?=$nav->first('
                                <li>
                                    <a class="MKpageU" href=""  iu="'.$id.'" ref={nr}>First</a>
                                </li>');?>
                                <?=$nav->previous('
                                <li>
                                    <a class="MKpageU" href="" iu="'.$id.'" ref={nr}>Prev</a>
                                </li>');?>
                                <?=$nav->numbers('
                                <li>
                                    <a class="MKpageU" href="" iu="'.$id.'" ref={nr}>{nr}</a>
                                </li>', '
                                <li>
                                    <a class="MKpage" href="" ref={nr}>{nr}</a>
                                </li>');?>
                                <?=$nav->next('
                                <li>
                                    <a class="MKpageU" href="" iu="'.$id.'" ref={nr}>Next</a>
                                </li>');?>
                                <?=$nav->last('
                                <li>
                                    <a class="MKpageU" href="" iu="'.$id.'" ref={nr}>Last</a>
                                </li>');?>
                            </ul>
                        </div>
                        <div class="pull-right">
                            <?=$nav->info('Page {page} of {pages}');?>
                        </div>
                    </tbody>
                </table>
				                        <div class="pull-right">
				                            <?=$nav->info('Page {page} of {pages}');?>
                        </div>
				                        <div class="pagination pagination-centered">
                            <ul>
                                <?=$nav->first('
                                <li>
                                    <a class="MKpageU" href=""  iu="'.$id.'" ref={nr}>First</a>
                                </li>');?>
                                <?=$nav->previous('
                                <li>
                                    <a class="MKpageU" href="" iu="'.$id.'" ref={nr}>Prev</a>
                                </li>');?>
                                <?=$nav->numbers('
                                <li>
                                    <a class="MKpageU" href="" iu="'.$id.'" ref={nr}>{nr}</a>
                                </li>', '
                                <li>
                                    <a class="MKpage" href="" ref={nr}>{nr}</a>
                                </li>');?>
                                <?=$nav->next('
                                <li>
                                    <a class="MKpageU" href="" iu="'.$id.'" ref={nr}>Next</a>
                                </li>');?>
                                <?=$nav->last('
                                <li>
                                    <a class="MKpageU" href="" iu="'.$id.'" ref={nr}>Last</a>
                                </li>');?>
                            </ul>
                        </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function() {
	$('.MKpageU').click(function(){
		var request = $(this).attr( "ref" );
		var iu = $(this).attr("iu");
		if(request==undefined){
			request="";
		}
		$.ajax({			
			type: "GET",
			url: "./user.php?id="+iu+"&page="+request,
			//beforeSend: ajaxindicatorstart('loading data.. please wait..'),
			success: function(a) {
				$('#responseU').html(a);
								 $('html, body').animate({
        scrollTop: $("#cursor").offset().top
    }, 2000);
				//ajaxindicatorstop();
			}
		});
	});
	
			$links=$('a');
			$links.on('click', function(e){
				e.preventDefault();
			});
});

	</script>
