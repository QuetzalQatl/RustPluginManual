<?php
require_once("./inc/config.php");


$req = isset($_REQUEST['req']) ? $_REQUEST['req'] : '';
if($req == "TopP"){
?>
<h1>···TOP 10!···</h1>
<div class="">
				<ul class="nav nav-tabs">
					<li class="active"><a data-toggle="tab" href="#tab1">Top 10 By Points</a></li>
				</ul>

				<div class="tab-content active">
					<div id="tab1" class="tab-pane active">
					<div id="cursor" tabindex="1">
						<table class="table">
							<thead>
								<tr><th>Description</th></tr>
							</thead>
							<tbody>
								<?php
								conexionBD();
									$latest = DB::query("SELECT name, points FROM users ORDER BY points DESC LIMIT 0, 10");
									$color = "a";
									$num = "1";
									foreach ($latest as $row){
										if($color=="a"){
											?>
											<tr><td class="alert-success"><strong><?=$num;?>|</strong> <?=$row['name'];?> with a total of <?=$row['points'];?> points</td></tr>
											<?php
											$num++;
											$color = "b";
										}elseif($color=="b"){
											?>
											<tr><td class="alert-info"><strong><?=$num;?>|</strong> <?=$row['name'];?> with a total of <?=$row['points'];?> points</td></tr>
											<?php
											$num++;
											$color = "a";
										}
									}
								?>							
							</tbody>
						</table>
					</div>
				</div> <!-- /tab-content -->
			</div>
<?php	
}elseif($req == "TopK"){
	?>
	<h1>---TOP 10!---</h1>
<div class="">
				<ul class="nav nav-tabs">
					<li class="active"><a data-toggle="tab" href="#tab1">Top 10 By Kills</a></li>
				</ul>

				<div class="tab-content active">
					<div id="tab1" class="tab-pane active">
					<div id="cursor" tabindex="1">
						<table class="table">
							<thead>
								<tr><th>Description</th></tr>
							</thead>
							<tbody>
								<?php
								conexionBD();
									$latest = DB::query("SELECT name, killings FROM users ORDER BY killings DESC LIMIT 0, 10");
									$color = "a";
									$num = "1";
									foreach ($latest as $row){
										if($color=="a"){
											?>
											<tr><td class="alert-success"><strong><?=$num;?>|</strong> <?=$row['name'];?> with a total of <?=$row['killings'];?> killings</td></tr>
											<?php
											$num++;
											$color = "b";
										}elseif($color=="b"){
											?>
											<tr><td class="alert-info"><strong><?=$num;?>|</strong> <?=$row['name'];?> with a total of <?=$row['killings'];?> killings</td></tr>
											<?php
											$num++;
											$color = "a";
										}
									}
								?>							
							</tbody>
						</table>
					</div>
				</div> <!-- /tab-content -->
			</div>
	<?php
}elseif($req == "TopD"){
	?>
	<h1>~~~TOP 10!~~~</h1>
<div class="">
				<ul class="nav nav-tabs">
					<li class="active"><a data-toggle="tab" href="#tab1">Top 10 By Deaths</a></li>
				</ul>

				<div class="tab-content active">
					<div id="tab1" class="tab-pane active">
					<div id="cursor" tabindex="1">
						<table class="table">
							<thead>
								<tr><th>Description</th></tr>
							</thead>
							<tbody>
								<?php
								conexionBD();
									$latest = DB::query("SELECT name, deaths FROM users ORDER BY deaths DESC LIMIT 0, 10");
									$color = "a";
									$num = "1";
									foreach ($latest as $row){
										if($color=="a"){
											?>
											<tr><td class="alert-success"><strong><?=$num;?>|</strong> <?=$row['name'];?> with a total of <?=$row['deaths'];?> deaths</td></tr>
											<?php
											$num++;
											$color = "b";
										}elseif($color=="b"){
											?>
											<tr><td class="alert-info"><strong><?=$num;?>|</strong> <?=$row['name'];?> with a total of <?=$row['deaths'];?> deaths</td></tr>
											<?php
											$num++;
											$color = "a";
										}
									}
								?>							
							</tbody>
						</table>
					</div>
				</div> <!-- /tab-content -->
			</div>
	<?php
}else{
	?>
	<h1>BAD REQUEST!</h1>
<div class="">
				<ul class="nav nav-tabs">
					<li class="active"><a data-toggle="tab" href="#tab1">BAD REQUEST</a></li>
				</ul>

				<div class="tab-content active">
					<div id="tab1" class="tab-pane active">
						<h1>ERROR - REQUEST NOT FOUND!</h1>
					</div>
				</div> <!-- /tab-content -->
			</div>
	<?php
}
?>



