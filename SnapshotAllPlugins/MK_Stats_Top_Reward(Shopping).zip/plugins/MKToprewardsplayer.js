var MKToprewardsplayer = {
	Name : Name = "toprewardsplayer",
    Title : "Top/Rewards Player",
	Description : "Show Top Players by number of murders committed, and give a reward for it.",
    Version : V(0, 0, 04),
    HasConfig : true,
	Author : "LEO318x",
    OnServerInitialized : function () {
		dataLang = data.GetData("MKlanguages");
    },
	Init : function () {
		// User Options
			command.AddChatCommand("top", this.Plugin, "cmdTop");
			command.AddChatCommand("stats", this.Plugin, "cmdStats");
			command.AddChatCommand("exchange", this.Plugin, "cmdMKexchange");
			command.AddChatCommand("yes", this.Plugin, "cmdYes");
	},
    LoadDefaultConfig : function () {
		// Enable or Disable Options
		this.Config.Options = {
			"MySQL" : true, //If false the top10 not working, only stats and rewards
			"MySQLKEY" : 'TheKey0123$', //This is the key to interactuar con la pagina, no es el password de la base de datos
			"WebStats" : true, //Only True if MySQL is true.
			"URL" : 'http://yourwebpageorIP/request.php', //URL to stats
			"Language": "en", //Default Lenguage
			"TPReward" : true, //Disabled for now
			"Players" : true, //Disabled for now
			"Animalkills" : true, //Disabled for now
			"SuicideDeaths" : true, //Working
			"Naturalcausesdeath" : true, //Disabled for now
		},
		
		// Points
		this.Config.Points = {
			"PlayerKillerPoint" : 2, //Point to the killer
			"AnimalKillerPoint": 1, //Point to kill animal
			"PlayerDeathPoint" : 2, //Point lost for Death
			"PlayerDeathEnvironment" : 3, //Natural cause
			"PlayerSuicide" : 5, //Suicides
		},
		
		// Money
		this.Config.Money = {
			"Killing" : 100, // 0 to disable, if disable the player can not exchange items
			"KillingAnimal" : 50, //0 to disable, if disable the player can not exchange items
			"Respawn" : 50, //0 to disable, apply only natural deaths and suicides
		},
		
		this.Config.Prices = {
		/*	//Resources //Disabled for now
				//Resources Easy Items
					"battery_small": 100,
					"bone_fragment": 100,
					"can_beans_em": 100,
					"can_tuna_empty": 100,
					"charcoal": 100,
					"cloth": 100,
					"fat_animal": 100,
					"gunpowder": 100,
					"lowgradefuel": 100,
					"metal_fragments": 100,
					"metal_ore": 100,
					"metal_refined": 100,
					"paper": 100,
					"skull_human": 100,
					"skull_wolf": 100,
					"stones": 100,
					"sulfur": 100,
					"sulfur_ore": 100,
					"wood" : 100,
				
				//Resources Moderated Items

				//Resources Hight Items	*/
			
			//Tools
				//Tools Easy Items
				"axe_salvaged": 125,
				"flare": 50,
				"hammer": 10,
				"hammer_salvaged": 50,
				"hatchet": 75,
				"icepick_salvaged": 200,
				"pickaxe": 110,
				"rock": 100,
				"stonehatchet": 50,
				"torch": 100,
				
			/*//Medical //Disabled for now
				//Medical Easy Items
				"antiradpills": 100,
				"bandage": 100,
				"blood": 100,
				"largemedkit": 100,
				"syringe_medical": 100,*/
			
			/*//Food //Disabled for now
				//Food Easy Items
				"apple": 100,
				"black": 100,
				"blueberries": 100,
				"can_beans": 100,
				"can_tuna": 100,
				"chicken_cooke": 100,
				"chocholate": 100,
				"granobar": 100,
				"smallwaterbottle": 100,
				"wolfmeat_cooke": 100,*/
				
			//Attire
				//Attire Easy Items
				"bucket_helmet": 100,
				"burlap_gloves": 100,
				"bulap_shirt": 100,
				"burlap_shoes": 100,
				"burlap_trousers": 100,
				"coffeecan_helmet": 100,
				"hazmat_boots": 100,
				"hazmat_gloves": 100,
				"hazmat_helmet": 100,
				"hazmat_jacket": 100,
				"hazmat_pants": 100,
				"jacket_snow": 100,
				"jacket_snow2": 100,
				"jacket_snow3": 100, 
				"metal_facemask": 100,
				"metal_plate_torso": 100,
				"urban_boots": 100,
				"urban_jacket": 100,
				"urban_pants": 100,
				"urban_shirt": 100,
				"vagabond_jack": 100,
				
			//Items
				//Items Easy Items
				"bed": 100,
				"box_wooden": 25,
				"box_wooden_large": 60,
				"campfire": 100,
				"furnace": 80,
				"latern": 10,
				"sleepingbag": 10,
				
			//Construction
				//Construction Easy Items
				"building_planner": 10,
				"cupboard.tool": 100,
				"lock.code": 175,
				"lock.key": 25,
				
			//Weapon
				//Weapon Easy Items
				"bow_hunting": 50,
				"knife_bone": 10,
				"pistol_eoka": 100,
				"pistol_revolver": 200,
				"rifle_ak": 800,
				"rifle_bolt": 600,
				"shotgun_water": 200,
				"smg_thompson": 300,
				"spear_stone": 30,
				"spear_wooden": 30,
				
			//Ammunition
				//Ammunition Easy Items
				"ammo_pisto": 50,
				"ammo_rifle": 50,
				"ammo_shotgun": 50,
				"arrow_wooden": 50,
			
			//Traps
				//Traps Hard Items
				"trap_bear": 200,
		},
		
		this.Config.ItemsPerPurchase = {
			//Resources
				//Resources Easy Items
					"battery_small": 1,
					"bone_fragment": 1,
					"can_beans_em": 1,
					"can_tuna_empty": 1,
					"charcoal": 1,
					"cloth": 1,
					"fat_animal": 1,
					"gunpowder": 1,
					"lowgradefuel": 1,
					"metal_fragments": 1,
					"metal_ore": 1,
					"metal_refined": 1,
					"paper": 1,
					"skull_human": 1,
					"skull_wolf": 1,
					"stones": 1,
					"sulfur": 1,
					"sulfur_ore": 1,
					"wood" : 1,
				
				//Resources Moderated Items

				//Resources Hight Items	
			
			//Tools
				//Tools Easy Items
				"axe_salvaged": 1,
				"flare": 1,
				"hammer": 1,
				"hammer_salvaged": 1,
				"hatchet": 1,
				"icepick_salvaged": 1,
				"pickaxe": 1,
				"rock": 1,
				"stonehatchet": 1,
				"torch": 1,
				
			//Medical
				//Medical Easy Items
				"antiradpills": 1,
				"bandage": 1,
				"blood": 1,
				"largemedkit": 1,
				"syringe_medical": 1,
			
			//Food
				//Food Easy Items
				"apple": 1,
				"black": 1,
				"blueberries": 1,
				"can_beans": 1,
				"can_tuna": 1,
				"chicken_cooke": 1,
				"chocholate": 1,
				"granobar": 1,
				"smallwaterbottle": 1,
				"wolfmeat_cooke": 1,
				
			//Attire
				//Attire Easy Items
				"bucket_helmet": 1,
				"burlap_gloves": 1,
				"bulap_shirt": 1,
				"burlap_shoes": 1,
				"burlap_trousers": 1,
				"coffeecan_helmet": 1,
				"hazmat_boots": 1,
				"hazmat_gloves": 1,
				"hazmat_helmet": 1,
				"hazmat_jacket": 1,
				"hazmat_pants": 1,
				"jacket_snow": 1,
				"jacket_snow2": 1,
				"jacket_snow3": 1, 
				"metal_facemask": 1,
				"metal_plate_torso": 1,
				"urban_boots": 1,
				"urban_jacket": 1,
				"urban_pants": 1,
				"urban_shirt": 1,
				"vagabond_jack": 1,
				
			//Items
				//Items Easy Items
				"bed": 1,
				"box_wooden": 1,
				"box_wooden_large": 1,
				"campfire": 1,
				"furnace": 1,
				"latern": 1,
				"sleepingbag": 1,
				
			//Construction
				//Construction Easy Items
				"building_planner": 1,
				"cupboard.tool": 1,
				"lock.code": 1,
				"lock.key": 1,
				
			//Weapon
				//Weapon Easy Items
				"bow_hunting": 1,
				"knife_bone": 1,
				"pistol_eoka": 1,
				"pistol_revolver": 1,
				"rifle_ak": 1,
				"rifle_bolt": 1,
				"shotgun_water": 1,
				"smg_thompson": 1,
				"spear_stone": 1,
				"spear_wooden": 1,
				
			//Ammunition
				//Ammunition Easy Items
				"ammo_pisto": 1,
				"ammo_rifle": 1,
				"ammo_shotgun": 1,
				"arrow_wooden": 1,
			
			//Traps
				//Traps Hard Items
				"trap_bear": 1,
				
		},
		
		this.Config.URL = {
			"URL" : this.Config.Options['URL']+"?key="+this.Config.Options['MySQLKEY'], //don't touch :)
		},

		// Mensajes
		this.Config.Messages = {
			"TypeDeath0" : "Generic",
			"TypeDeath1" : "Hunger",
			"TypeDeath2" : "Thirst",
			"TypeDeath3" : "Cold",
			"TypeDeath4" : "Drowned",
			"TypeDeath5" : "Heat",
			"TypeDeath6" : "Bleeding",
			"TypeDeath7" : "Poison",
			"TypeDeath8" : "Suicide",
			"TypeDeath9" : "Bullet",
			"TypeDeath10" : "Slash",
			"TypeDeath11" : "Blunt",
			"TypeDeath12" : "Fall",
			"TypeDeath13" : "Radiation",
			"TypeDeath14" : "Bite",
			"TypeDeath15" : "Stab",
			"TypeDeath16" : "LAST",
		}
    },
	OnPlayerInit : function (player){
			playerID = rust.UserIDFromPlayer(player);
			Data = "&op=3&userid="+playerID;
			URL = this.Config.URL['URL'];
			webrequests.EnqueueGet(URL+Data, function(code, response) {
				if(response == "KEY-NOT-EQUAL"){
					print(dataLang.en["msg1"]);
				}else if(response == playerID){
					print(dataLang.en["msg2"]);
				}else{
						Data = "&op=1&userid="+playerID+"&name="+player.displayName+"&points=0&killings=0&deaths=0&suicides=0&money=0";
						webrequests.EnqueueGet(URL+Data, function(code, response) {
							if(response == "SUCCESS-PLAYER-ADDED"){
								print(dataLang.en["msg3"]);
							}else{
								print(dataLang.en["msg4"]);
								print("ERROR-CONNECT_345|------->"+response);
							}
						}, this.Plugin);					
					};
			}, this.Plugin);
	},
	
	//Exchange items
	cmdMKexchange : function(player, cmd, args){
		global = importNamespace("");
		playerID = rust.UserIDFromPlayer(player);
		args = args.toString().split(",");
		Name = args[0];
		if(args[0]=="" && args[1]=="" && args[2]){
			rust.SendChatMessage(player, "SERVER", "<color=#FF0000>"+dataLang.en["msg11"]+"</color>", "");
		}else{
			Price = this.Config.Prices[args[0]];
			Value = this.Config.ItemsPerPurchase[args[0]] * args[1];
			Total = (this.Config.Prices[args[0]] * args[1]).toFixed(2);
			dataObj = data.GetData("MKexchanges");
			if(dataObj[playerID]){
				dataObj[playerID] = {
					"Status" : "OK",
					"Name" : args[0],
					"Value" : Value,
					"Total": Total,
				}	
			}else{
				dataObj[playerID] = {
					"Status" : "OK",
					"Name" : args[0],
					"Value" : Value,
					"Total": Total,
				}
			}
			data.SaveData("MKexchanges");
			rust.SendChatMessage(player, "SERVER", "<color=#FFC000>"+eval(dataLang.en["msg5"])+"</color>", "");
			rust.SendChatMessage(player, "SERVER", "<color=#00FF1A>"+dataLang.en["msg6"]+"</color>", "");
			}
			//Blueprint //Disabled for now
				//inv.GiveItem(global.ItemManager.CreateByItemID(11864, 1, false), inv.containerMain);
	},
	
	cmdYes : function(player){
		playerID = rust.UserIDFromPlayer(player);
		dataObj = data.GetData("MKexchanges");
		URL = this.Config.URL['URL'];
		Data = "&op=8&userid="+playerID+"&money="+dataObj[playerID]["Total"];
			if(dataObj[playerID]["Status"]!="NO"){			
				webrequests.EnqueueGet(URL+Data, function(code, response) {				
					if(response=="SUCCESS"){
						var inv = player.inventory;
						inv.GiveItem(global.ItemManager.CreateByName(dataObj[playerID]["Name"], parseInt(dataObj[playerID]["Value"])), inv.containerMain);
						rust.SendChatMessage(player, "SERVER", dataLang.en["msg7"], "");
						dataObj[playerID] ={
							"Status" : "NO",
							"Name" : 0,
							"Value": 0,
							"Total": 0,
						}						
					}else if(response=="FAIL"){
						rust.SendChatMessage(player, "SERVER", dataLang.en["msg8"], "");
						rust.SendChatMessage(player, "SERVER", dataLang.en["msg9"], "");
						dataObj[playerID] ={
							"Status" : "NO",
							"Name" : 0,
							"Value": 0,
							"Total": 0,
						}
					}else{
						rust.SendChatMessage(player, "SERVER", dataLang.en["msg10"], "");
					}
				data.SaveData("MKexchanges");
				},  this.Plugin);
			}else{
					rust.SendChatMessage(player, "SERVER", dataLang.en["msg12"], "");
			}			
	},
	
	
	// When user write in chat "/top", this code below its executed
	cmdTop : function (player) {
		Data = "&op=2&req=1";
		webrequests.EnqueueGet(this.Config.URL['URL']+Data, function(code, response) {
			response = JSON.parse(response);
			for (var i = 0; i < 10; i++){
				rust.SendChatMessage(player, "SERVER", eval(dataLang.en["msg13"]), "");
			}
		}, this.Plugin);				
	},
	cmdStats : function (player){
		playerID = rust.UserIDFromPlayer(player);
		Data = "&op=2&req=2&userid="+playerID;
		webrequests.EnqueueGet(this.Config.URL['URL']+Data, function(code, response) {
			response = JSON.parse(response);
			print(response[0]['points']);
			rust.SendChatMessage(player, "SERVER", eval(dataLang.en["msg14"]), "");
			rust.SendChatMessage(player, "SERVER", eval(dataLang.en["msg15"]), "");
		},  this.Plugin);
	},

	OnEntityDeath : function (entity, hitinfo){
		if(hitinfo == null){
			if(this.Config.Options["Naturalcausesdeath"]){
				if(entity.ToPlayer()){
					this.PlayerDiedFromNaturalCause(entity);					
				}
			}
		}else{
			if(entity.ToPlayer()){
				this.PlayerDeath(entity, hitinfo);
			}else if(entity.GetComponent("BaseNPC")){
				this.EntityDeath(entity, hitinfo);
			}	
		}		
	},

	EntityDeath : function(victim, hitinfo){
		if(hitinfo.Initiator.ToPlayer()){
			attacker = hitinfo.Initiator.ToPlayer();
			animal = victim.GetComponent("BaseNPC");
			killer = attacker.displayName;
			killerid = rust.UserIDFromPlayer(attacker);
			killed = "NPC";
			killedid = "npc";
			type = "pve";
			URL = this.Config.URL['URL']
			Data = "&op=7&userid="+killerid+"&name="+killer+"&useridD=2&nameD="+killed+"&points="+this.Config.Points['AnimalKillerPoint']+"&money="+this.Config.Money['KillingAnimal'];
			webrequests.EnqueueGet(URL+Data, function(code, response) {
				 
				},  this.Plugin);
			rust.SendChatMessage(attacker, "SERVER", eval(dataLang.en["msg16"]), "");
		}
		
	},
	
	PlayerDeath : function (victim, hitinfo){
		var Rust = importNamespace("Rust");
		if(hitinfo.damageTypes.GetMajorityDamageType() == Rust.DamageType.Suicide){
			if(this.Config.Options["SuicideDeaths"]){
				killed = victim.displayName;
				killeid = rust.UserIDFromPlayer(victim);
				killer = "suicide";
				type = "naturalcause";
				Data = "&op=4&userid="+killeid+"&name="+killed+"&pointsleft="+this.Config.Points['PlayerSuicide']+"&money="+this.Config.Money['Respawn'];
				webrequests.EnqueueGet(this.Config.URL['URL']+Data, function(code, response) {
					rust.SendChatMessage(victim, "SERVER", eval(dataLang.en["msg17"]), "");
					rust.SendChatMessage(victim, "SERVER", eval(dataLang.en["msg18"]), "");
				},  this.Plugin);
			}
		}else if(hitinfo.Initiator.ToPlayer()){
			attacker = hitinfo.Initiator.ToPlayer();
			if (rust.UserIDFromPlayer(attacker) == rust.UserIDFromPlayer(victim)){
				if(this.Config.Options["Naturalcausesdeath"]){
					killed = victim.displayName;
					killeid = rust.UserIDFromPlayer(victim);	
					type = "naturalcause";
					URL = this.Config.URL['URL'];
					Data = "&op=5&userid="+killeid+"&name="+killed+"&pointsleft="+this.Config.Points['PlayerDeathEnvironment']+"&money="+this.Config.Money['Respawn'];
					webrequests.EnqueueGet(URL+Data, function(code, response) {
						rust.SendChatMessage(victim, "SERVER", eval(dataLang.en["msg19"]), "");
						rust.SendChatMessage(victim, "SERVER", eval(dataLang.en["msg20"]), "");
					},  this.Plugin);
				}
			}else {
				if(this.Config.Options["Players"]){
					killer = attacker.displayName;
					killerid = rust.UserIDFromPlayer(attacker);
					killed = victim.displayName;
					killedid = rust.UserIDFromPlayer(victim);
					type = "pvp";
					URL = this.Config.URL['URL'];
					// weapon
					if(!victim.IsConnected()){
						Data = "&op=6&userid="+killerid+"&name="+killer+"&useridD="+killedid+"+&nameD="+killed+"&pointsleft="+this.Config.Points['PlayerDeathPoint']+"&points="+this.Config.Points['PlayerKillerPoint']+"&money="+this.Config.Money['Killing'];
						webrequests.EnqueueGet(URL+Data, function(code, response) {
						rust.SendChatMessage(attacker, "SERVER", eval(dataLang.en["msg21"]), "");
						rust.BroadcastChat("SERVER", eval(dataLang.en["msg22"]), "");
						},  this.Plugin);
					
					}else{
						Data = "&op=6&userid="+killerid+"&name="+killer+"&useridD="+killedid+"+&nameD="+killed+"&pointsleft="+this.Config.Points['PlayerDeathPoint']+"&points="+this.Config.Points['PlayerKillerPoint']+"&money="+this.Config.Money['Killing'];
						webrequests.EnqueueGet(URL+Data, function(code, response) {
						rust.SendChatMessage(attacker, "SERVER", eval(dataLang.en["msg21"]), "");
						rust.SendChatMessage(victim, "SERVER", eval(dataLang.en["msg23"]), "");						
						},  this.Plugin);
					}	
				}
			}
		}
	},
}
